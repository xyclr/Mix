/**
 * Created by Alex on 16/1/9.
 */
(function($){
    var clothes = clothes || {};
    clothes = {

        ClothesType : [],

        init : function(){
            var that = this;

            //绑定事件
            this.event();

            //初始化会员卡信息
            this.LoadCardInfo(_Card,$('.J_ct-cart-info'));

            $.each(_Clothes,function(i,v){
                that.ClothesType.push([i,v.name]);
            })
        },

        event : function(){
            var that = this;
            var $clothesSelModal = $("#clothesSelModal");
            var $clothesSelModalClose = $clothesSelModal.find(".close");
            var $checkOutModal = $("#checkOutModal");
            var $orderTable = $(".J-order-table");

            //会员卡信息隐藏显示
            $(".J_card-toggle").bind("click",function(){
                var me = $(this);
                var $cart = $(".ct-card");
                if(me.hasClass("card-show")) {
                    me.removeClass("card-show").html("更多");
                    $cart.hide();
                } else {
                    me.addClass("card-show").html("收起");
                    $cart.show();
                }
            });

            //衣服类型选择弹出框
            $orderTable.delegate(".J-clothes-sel","click",function(){
                var $parent = $(this).parents('tr');
                $clothesSelModal.modal('show', 'fit');
            });
            $clothesSelModal.on('show.zui.modal', function() {
                //分类和衣服名称初始化
                var ret = '<option value="-1">-请选择-</option>';
                that.ClothesType.forEach(function(v){
                    ret += '<option value="'+ v[0] +'">' + v[1] + '</option> ';
                });
                $(this).find(".J-clothes-ty").html(ret);
                $(this).find(".J-clothes-name").html('<option value="0">-请先选择分类-</option>');
            });
            $clothesSelModal.find(".J-btn-submit").click(function(){
                var valTy = $clothesSelModal.find(".J-clothes-ty").children('option:selected').val();
                var valName = $clothesSelModal.find(".J-clothes-name").children('option:selected').val();
                var clotheInfo = that.GetClotheInfo(valTy,valName);
                that.InsertOrderData(clotheInfo,$(".J-order-table tr.cur"));
                $clothesSelModalClose.click();
                return false;
            });
            $clothesSelModal.find(".J-btn-cancel").click(function(){
                $clothesSelModalClose.click();
                return false;
            });
            $clothesSelModal.find(".J-clothes-ty").change(function(){
                var val = $(this).children('option:selected').val();
                var ret = '';
                if(val == -1) {
                    $clothesSelModal.find(".J-clothes-name").html('<option value="0">-请先选择分类-</option>');
                    return
                };
                that.GetClothesName(val).forEach(function(v){
                    ret += '<option value="'+ v[0] +'">' + v[1] + '</option> ';
                });
                $clothesSelModal.find(".J-clothes-name").html(ret);
            });

            //订单管理表格
            $orderTable.delegate('tr','click',function(){
                var me = $(this);
                if(!me.hasClass('cur')) {
                    me.addClass('cur');
                    me.siblings().removeClass("cur");
                }
            });
            $orderTable.delegate('.J-tr-copy','click',function(){
                var $tr = $(this).parents("tr");
                var $orderInfo = $(".J-order-table tr.cur").data("order");
                if(!$(".J-order-table tr.tr-order" || !$tr.hasClass("hasData")).not("hasData").length)  return;
                var $target = $(".J-order-table tr.tr-order").not(".hasData").eq(0);
                $target.addClass("hasData").html($(".J-order-table tr.hasData.cur").html());
                $target.find(".o-ty input").val($(".tr-order.cur .o-ty input").val());
                $target.find(".o-xc input").val($(".tr-order.cur .o-xc input").val());
                $target.data("order",$orderInfo);
                $orderTable.find("tr").removeClass("cur");
                $target.addClass("cur");
            });
            $orderTable.delegate('.J-tr-del','click',function(){
                var $tr = $(this).parents("tr");
                if($tr.hasClass("cur")) $(".J-order-table tr").eq(0).addClass("cur");
                $tr.remove();
            });
            $(".J-tr-add").click(function(){
                var len = $orderTable.find(".tr-order").length;
                var tmp = '<tr class="tr-order '+ (len ? "" : "cur") +'"> <td class="o-id">0</td> <td class="o-ty"><input type="text" class="form-control J-clothes-sel"></td> <td class="o-color">-</td> <td class="o-xc">-</td> <td class="o-brand">-</td> <td class="o-">-</td> <td class="">-</td> <td>-</td> <td class="o-price">-</td> <td>-</td> <td><button class="btn btn-mini mr5 J-tr-copy f-dn" type="button">复制</button><button class="btn btn-mini J-tr-del" type="button">删除</button></td> </tr>';
                $(".J-order-table tbody").append(tmp);
            });

            //去结算
            $(".J-btn-checkout").click(function(){
                $checkOutModal.modal('show', 'fit');
            });
            $checkOutModal.on('show.zui.modal', function() {
                $("#card_number").text(_Card.id);
                $("#offsale").text(_Card.id);
            });
        },

        //初始化会员卡信息
        LoadCardInfo : function(data,obj){
            var ret = '<input type="hidden"  />' +
                '<span class="mr10"> 住址：' + (data.address || "--") + '</span> ' +
                '<span class="mr10"> 电话：' + (data.tel || "--")  + '</span> ' +
                '<span class="mr10"> 姓名：' + (data.username || "--")  + '</span> ' +
                '<span class="mr10"> 次数：' + (data.num || "--")  + '</span> ' +
                '<span class="mr10"> 总额：' + (data.total || "--")  + '</span> ' +
                '<span class="mr10"> 卡号：' + (data.id || "--")  + '</span>';
            obj.html(ret);
        },

        GetClothesName : function(data){
            var arr = [];
            $.each(_Clothes[data].sub,function(i,v){
                arr.push([i, v.name]);
            });
            return arr;
        },

        GetClotheInfo : function(valTy,valName){
            var obj = {};
            console.info(valTy);
            console.info(valName);
            $.each(_Clothes[valTy].sub[valName],function(i,v){
                obj[i] = v;
            });
            return obj;
        },

        InsertOrderData : function(clotheInfo,target){
            target.data("order",clotheInfo);
            target.addClass("hasData");
            target.find(".o-id").text(clotheInfo.id);
            target.find(".o-ty input").val(clotheInfo.name);
            target.find(".o-brand").html('<select name="brand" class="form-control"> <option value="2">七匹狼 </option> <option value="3">佐丹路 </option> <option value="4">VERO MODO </option> <option value="5">Armani Collezioni阿玛尼 </option> <option value="6">Agnona杰尼亚女牌 </option> <option value="7">Arc teryx始祖鸟 </option> <option value="8">ATTOS爱徒 </option> <option value="9">Bally巴利 </option> <option value="10">BALMAIN巴尔曼 </option> <option value="11">Berluti伯鲁提 </option> <option value="12">Bottega Veneta葆蝶家 </option> <option value="13">Burberry巴宝莉 </option> <option value="14">Canada goose加拿大天鹅 </option> </select>');
            target.find(".o-xc").html('<input type="text" class="form-control"/>');
            target.find(".o-num").html('<input type="text" value="1" class="form-control  f-tac"/>');
            target.find(".o-cl").html('<select name="wash_way" class="form-control"> <option value="1">标准</option> <option value="2">特种1</option> <option value="3">特种2</option> <option value="4">熨烫</option> <option value="5">团购</option> </select>');
            target.find(".o-price").text(clotheInfo.normal);
            target.find(".o-color").html('<select name="color" class="form-control"> <option value="#">白色</option> <option value="#">黑色</option> <option value="#">绿色</option> <option value="#">绿色</option> </select>');
        },

        //计算折扣信息
        CacOffSale : function(){

        }
    };
    clothes.init();
})(jQuery);