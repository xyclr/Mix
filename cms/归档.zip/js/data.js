var _Card = {
    id : "123342342",
    typename : "定制卡",
    catname : "定制卡10000",
    address : "地址",
    tel : "1388888888",
    username : "张三",
    num : "1000",
    total : "1000",
    //折扣信息 (折扣值,标准,特种1,特种2,熨烫,团购,团购价)
    discount : 0.7,
    discountMatch : [true, true, true, true, false, false]
};
var _Clothes = {
    //外套
    loosecoat : {
        type : 1,
        name : "外套",
        sub : {
            //羊毛衫
            cardigan : {
                id : "1046",
                type :"1",
                name : "羊毛衫",
                normal : 48,
                tz1 : 180,
                tz2 : null,
                dt : 28,
                tg : null,
                days : 3,
                safekeep : 99,
                series : "C"
            },

            //羊绒裤
            cashmereants : {
                id : "1047",
                type :"2",
                name : "羊绒裤",
                normal : 48,
                tz1 : 180,
                tz2 : null,
                dt : 28,
                tg : null,
                days : 3,
                safekeep : 99,
                series : "B"
            },

            //风衣
            windbreaker : {
                id : "1048",
                type :"3",
                name : "风衣",
                normal : 78,
                tz1 : 180,
                tz2 : null,
                dt : 48,
                tg : null,
                days : 3,
                safekeep : 99,
                series : "A"
            }
        }
    },

    //裤子
    trousers : {
        type : 2,
        name : "裤子",
        sub : {
            //休闲裤
            xxk : {
                id : "1062",
                name : "休闲裤",
                normal : 26,
                tz1 : null,
                tz2 : null,
                dt : null,
                tg : 8,
                days : 3,
                safekeep : 99,
                series : "A"
            }
        }
    },

    //裙子
    skirt : {
        type : 3,
        name : "裙子",
        sub : {
            //羊毛衫
            cardigan : {
                id : "1062",
                name : "裤子3",
                normal : 48,
                tz1 : 180,
                tz2 : null,
                dt : 28,
                tg : null,
                days : 3,
                safekeep : 99,
                series : "C"
            },

            //羊绒裤
            cashmereants : {
                id : "1062",
                name : "羊绒裤",
                normal : 48,
                tz1 : 180,
                tz2 : null,
                dt : 28,
                tg : null,
                days : 3,
                safekeep : 99,
                series : "C"
            }
        }
    },

    //上衣
    jacket : {
        type : 4,
        name : "上衣",
        sub : {

        }
    },

    //小件
    small : {
        type : 5,
        name : "小件",
        sub : {

        }
    },

    //卧卫
    ww : {
        type : 6,
        name : "卧卫",
        sub : {

        }
    },

    //家具
    furniture : {
        type : 7,
        name : "家具",
        sub : {

        }
    },

    //皮上衣
    leaclothing : {
        type : 8,
        name : "皮上衣",
        sub : {

        }
    },

    //皮包
    leabag : {
        type : 9,
        name : "皮包",
        sub : {

        }
    }
};

