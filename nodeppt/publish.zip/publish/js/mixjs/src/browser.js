var UA = window.navigator.userAgent;
